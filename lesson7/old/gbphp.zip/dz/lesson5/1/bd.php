<?
$link = mysqli_connect('localhost', 'root', '', 'gbphp') or die(mysqli_error($link));

define('DIR_IMG', 'images');