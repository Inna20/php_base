<?php
return [
    1 => "main.php",
    2 => "users.php",
    3 => "user.php",
    4 => "addUser.php",
    5 => "addUser_POST.php",
];